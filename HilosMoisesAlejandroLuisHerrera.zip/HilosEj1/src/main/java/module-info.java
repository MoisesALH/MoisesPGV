module ies.puertodelacruz.mlh.hilosej1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens ies.puertodelacruz.mlh.hilosej1 to javafx.fxml;
    exports ies.puertodelacruz.mlh.hilosej1;
}